import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import "./login.css";

export default function Login() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const handleLogin = async () => {
    try {
      const res = await API.post("/auth/login", form);

      localStorage.setItem("token", res.data.token);

      navigate("/dashboard");
    } catch (err) {
      alert(err.response?.data?.message || "Login failed");
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h1 className="logo">Hospital&nbsp;X</h1>

        <p className="subtext">Log in </p>

        <label>Username / Email</label>
        <input
          placeholder="mail@website.com"
          onChange={(e) =>
            setForm({ ...form, email: e.target.value })
          }
        />

        <label>Password</label>
        <input
          type="password"
          placeholder="********"
          onChange={(e) =>
            setForm({ ...form, password: e.target.value })
          }
        />

        <button className="login-btn" onClick={handleLogin}>
          Log in
        </button>

        <p className="auth-switch">
          No account?{" "}
          <span onClick={() => navigate("/register")}>
            Register here
          </span>
        </p>
      </div>
    </div>
  );
}
