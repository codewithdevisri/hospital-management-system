import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import "./login.css";

export default function Register() {
  const navigate = useNavigate();

  // ✅ UPDATED STATE (added username, removed confirmPassword)
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
  });

  const handleRegister = async (e) => {
    e.preventDefault();

    // ✅ UPDATED VALIDATION
    if (!form.username || !form.email || !form.password) {
      return alert("All fields required");
    }

    try {
      await API.post("/auth/register", {
        username: form.username, // ✅ send username
        email: form.email,
        password: form.password,
      });

      alert("Registered successfully ✅");
      navigate("/");
    } catch (err) {
      alert(err.response?.data?.message || "Registration failed");
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h1 className="logo">Hospital&nbsp;X</h1>
        <h2>Sign up</h2>

        {/* ✅ MOVED INSIDE FORM (better structure) */}
        <form onSubmit={handleRegister}>

          {/* USERNAME */}
          <label>Username</label>
          <input
            type="text"
            placeholder="Enter username"
            value={form.username}
            onChange={(e) =>
              setForm({
                ...form,
                username: e.target.value,
              })
            }
          />

          {/* EMAIL */}
          <label>Email</label>
          <input
            type="email"
            placeholder="mail@website.com"
            value={form.email}
            onChange={(e) =>
              setForm({ ...form, email: e.target.value })
            }
          />

          {/* PASSWORD */}
          <label>Password</label>
          <input
            type="password"
            placeholder="********"
            value={form.password}
            onChange={(e) =>
              setForm({ ...form, password: e.target.value })
            }
          />

          <button className="login-btn">Sign in</button>
        </form>

        <p className="auth-switch">
          Already have an account?{" "}
          <span onClick={() => navigate("/")}>
            Login here
          </span>
        </p>
      </div>
    </div>
  );
}