import { useState } from "react";
import api from "../services/api";

function PatientForm({ refresh }) {
  const [form, setForm] = useState({ name: "", bedId: "" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post("/patients", form);
      refresh();
      setForm({ name: "", bedId: "" });
    } catch {
      alert("Error adding patient");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Patient Name"
        value={form.name}
        onChange={(e) => setForm({ ...form, name: e.target.value })}
      />
      <input
        placeholder="Bed ID"
        value={form.bedId}
        onChange={(e) => setForm({ ...form, bedId: e.target.value })}
      />
      <button>Add Patient</button>
    </form>
  );
}

export default PatientForm;