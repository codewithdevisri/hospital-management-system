import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";

export default function Dashboard() {
  const navigate = useNavigate();

  const [showModal, setShowModal] = useState(false);

  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState("");

  const [form, setForm] = useState({
    name: "",
    bedId: "",
  });

  return (
    <div className="dashboard">

      {/* TOP BAR */}
      <div className="topbar">
        <h3>Username</h3>
        <span className="logout" onClick={() => navigate("/")}>
          🔴 Log Out
        </span>
      </div>

      {/* NAVBAR */}
      <div className="navbar">
        <button className="create-btn" onClick={() => setShowModal(true)}>
          <b>Create Patient</b>
        </button>
        <div className="divider"></div>
        <h1 className="title">Dashboard</h1>

        <div className="search">
          <input
            placeholder="Patient name, Bed ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <span className="search-icon">🔍</span>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div className="content">

        {/* SHOW PATIENTS */}
        {patients
          .filter(
            (p) =>
              p.name.toLowerCase().includes(search.toLowerCase()) ||
              p.bedId.toLowerCase().includes(search.toLowerCase())
          )
          .map((p, index) => (
            <div key={index} className="patient-section">
              <p className="room">{p.bedId}</p>

              <div className="patient-card">
                <p>{p.name}</p>
              </div>
            </div>
          ))}

        {/* DEFAULT CARD */}
        {patients.length === 0 && (
          <div className="patient-section">
            <p className="room">101</p>

            <div className="patient-card">
              <p>PATIENT NAME</p>
            </div>
          </div>
        )}

        {/* MODAL */}
        {showModal && (
          <div className="modal">
            <div className="modal-box">

              <div className="modal-header">
                <h3>Create Patient</h3>
              </div>

              <div className="modal-body">
                <label>Patient Name</label>
                <input
                  name="name"
                  value={form.name}
                  onChange={(e) =>
                    setForm({ ...form, name: e.target.value })
                  }
                />

                <label>Bed ID</label>
                <input
                  name="bedId"
                  value={form.bedId}
                  onChange={(e) =>
                    setForm({ ...form, bedId: e.target.value })
                  }
                />

                <div className="modal-actions">
                  <button
                    className="save-btn"
                    onClick={() => {
                      if (!form.name || !form.bedId) {
                        alert("Please fill all fields");
                        return;
                      }

                      setPatients([...patients, form]);
                      setForm({ name: "", bedId: "" });
                      setShowModal(false);
                    }}
                  >
                    Save
                  </button>

                  <button
                    className="cancel-btn"
                    onClick={() => setShowModal(false)}
                  >
                    Cancel
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
}